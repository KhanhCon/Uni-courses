x = 10;
y = 5;
disp(confusing_function(x,y));
clear x y