
Running generate_results script will promt you to select a folder. Select face_img then it will generate the results